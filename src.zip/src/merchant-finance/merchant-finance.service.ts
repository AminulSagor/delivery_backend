import {
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource, In, Between, ILike } from 'typeorm';
import { MerchantFinance } from './entities/merchant-finance.entity';
import { MerchantFinanceTransaction } from './entities/merchant-finance-transaction.entity';
import { User } from '../users/entities/user.entity';
import { Merchant } from '../merchant/entities/merchant.entity';
import { Parcel, ParcelStatus } from '../parcels/entities/parcel.entity';
import {
  FinanceTransactionType,
  FinanceReferenceType,
} from '../common/enums/finance-transaction-type.enum';
import {
  CreateTransactionDto,
  RecordParcelTransactionDto,
} from './dto/create-transaction.dto';
import {
  GetTransactionsQueryDto,
  GetAllMerchantsFinanceQueryDto,
} from './dto/get-transactions.dto';
import {
  AdjustBalanceDto,
  HoldBalanceDto,
  ReleaseHoldDto,
  ProcessWithdrawalDto,
} from './dto/adjust-balance.dto';
import {
  MerchantFinanceOverview,
  TransactionListResponse,
  AdminFinanceSummary,
} from './dto/finance-dashboard.dto';
import {
  MerchantEarningsGraph,
  MerchantEarningsGraphPoint,
  MerchantEarningsGraphQueryDto,
  MerchantFinancialStatement,
} from './dto/financial-statement.dto';

@Injectable()
export class MerchantFinanceService {
  private readonly logger = new Logger(MerchantFinanceService.name);
  private readonly earningsReferenceTypes: FinanceReferenceType[] = [
    FinanceReferenceType.PARCEL_DELIVERED,
    FinanceReferenceType.PARCEL_PARTIAL_DELIVERY,
    FinanceReferenceType.PARCEL_EXCHANGE,
    FinanceReferenceType.PARCEL_PAID_RETURN,
    FinanceReferenceType.RETURN_CHARGE,
  ];

  constructor(
    @InjectRepository(MerchantFinance)
    private financeRepository: Repository<MerchantFinance>,
    @InjectRepository(MerchantFinanceTransaction)
    private transactionRepository: Repository<MerchantFinanceTransaction>,
    @InjectRepository(User)
    private userRepository: Repository<User>,
    @InjectRepository(Merchant)
    private merchantRepository: Repository<Merchant>,
    @InjectRepository(Parcel)
    private parcelRepository: Repository<Parcel>,
    private dataSource: DataSource,
  ) {}

  // ===== FINANCE RECORD MANAGEMENT =====

  /**
   * Get or create merchant finance record
   */
  async getOrCreateFinance(merchantId: string): Promise<MerchantFinance> {
    let finance = await this.financeRepository.findOne({
      where: { merchant_id: merchantId },
    });

    if (!finance) {
      // Create new finance record
      finance = this.financeRepository.create({
        merchant_id: merchantId,
        current_balance: 0,
        pending_balance: 0,
        invoiced_balance: 0,
        processing_balance: 0,
        hold_amount: 0,
        total_earned: 0,
        total_withdrawn: 0,
        total_delivery_charges: 0,
        total_return_charges: 0,
        total_cod_collected: 0,
        total_parcels_delivered: 0,
        total_parcels_returned: 0,
        credit_limit: 0,
        credit_used: 0,
      });
      await this.financeRepository.save(finance);
      this.logger.log(`Created finance record for merchant ${merchantId}`);
    }

    return finance;
  }

  /**
   * Get the balance that a merchant can currently withdraw.
   * Held funds are not available and a negative result is exposed as zero.
   */
  async getAvailableBalance(merchantId: string): Promise<number> {
    const finance = await this.getOrCreateFinance(merchantId);
    const availableBalance = Math.max(
      0,
      Number(finance.current_balance) - Number(finance.hold_amount),
    );

    return this.roundMoney(availableBalance);
  }

  /**
   * Get merchant finance overview/dashboard
   */
  async getMerchantFinanceOverview(
    merchantId: string,
  ): Promise<MerchantFinanceOverview> {
    const finance = await this.getOrCreateFinance(merchantId);

    // Get user info
    const user = await this.userRepository.findOne({
      where: { id: merchantId },
    });

    if (!user) {
      throw new NotFoundException('Merchant not found');
    }

    // Get merchant profile
    const merchant = await this.merchantRepository.findOne({
      where: { user_id: merchantId },
    });

    return {
      merchant: {
        id: merchant?.id || '',
        user_id: user.id,
        name: user.full_name,
        phone: user.phone,
        email: user.email,
      },
      balance: {
        current_balance: Number(finance.current_balance),
        pending_balance: Number(finance.pending_balance),
        invoiced_balance: Number(finance.invoiced_balance),
        processing_balance: Number(finance.processing_balance),
        hold_amount: Number(finance.hold_amount),
        available_for_withdrawal: Math.max(
          0,
          Number(finance.current_balance) - Number(finance.hold_amount),
        ),
      },
      lifetime_stats: {
        total_earned: Number(finance.total_earned),
        total_withdrawn: Number(finance.total_withdrawn),
        total_cod_collected: Number(finance.total_cod_collected),
        total_delivery_charges: Number(finance.total_delivery_charges),
        total_return_charges: Number(finance.total_return_charges),
        total_parcels_delivered: finance.total_parcels_delivered,
        total_parcels_returned: finance.total_parcels_returned,
      },
      credit: {
        credit_limit: Number(finance.credit_limit),
        credit_used: Number(finance.credit_used),
        credit_available: Math.max(
          0,
          Number(finance.credit_limit) - Number(finance.credit_used),
        ),
      },
      last_activity: {
        last_transaction_at: finance.last_transaction_at,
        last_withdrawal_at: finance.last_withdrawal_at,
      },
    };
  }

  /**
   * Get financial statement cards for merchant dashboard
   */
  async getMerchantFinancialStatement(
    merchantId: string,
  ): Promise<MerchantFinancialStatement> {
    const finance = await this.getOrCreateFinance(merchantId);
    const now = new Date();
    const monthStart = new Date(
      Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1),
    );
    const monthEnd = new Date(
      Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1),
    );

    const monthlyEarningRaw = await this.transactionRepository
      .createQueryBuilder('txn')
      .select(
        `COALESCE(SUM(CASE
          WHEN txn.transaction_type = :creditType THEN txn.amount
          WHEN txn.transaction_type = :debitType THEN -txn.amount
          ELSE 0
        END), 0)`,
        'earnings',
      )
      .where('txn.merchant_id = :merchantId', { merchantId })
      .andWhere('txn.reference_type IN (:...referenceTypes)', {
        referenceTypes: this.earningsReferenceTypes,
      })
      .andWhere('txn.created_at >= :monthStart', { monthStart })
      .andWhere('txn.created_at < :monthEnd', { monthEnd })
      .setParameters({
        creditType: FinanceTransactionType.CREDIT,
        debitType: FinanceTransactionType.DEBIT,
      })
      .getRawOne<{ earnings: string | null }>();

    const lastPayout = await this.transactionRepository.findOne({
      where: {
        merchant_id: merchantId,
        reference_type: FinanceReferenceType.INVOICE_PAID,
      },
      order: { created_at: 'DESC' },
    });

    const availableBalance = Math.max(
      0,
      Number(finance.current_balance) - Number(finance.hold_amount),
    );
    const pendingPayments =
      Number(finance.pending_balance) +
      Number(finance.invoiced_balance) +
      Number(finance.processing_balance);
    const currentMonth = this.formatMonthName(monthStart);

    return {
      merchant_available_balance: {
        total: this.roundMoney(availableBalance),
      },
      pending_payment: {
        total: this.roundMoney(pendingPayments),
        month: currentMonth,
      },
      last_payout: {
        total: lastPayout ? this.roundMoney(Number(lastPayout.amount)) : 0,
        last_payout: lastPayout
          ? this.formatDayMonthYear(lastPayout.created_at)
          : null,
      },
      earning_this_month: {
        total: this.roundMoney(Number(monthlyEarningRaw?.earnings || 0)),
        month: currentMonth,
      },
      lifetime_earning: {
        total: this.roundMoney(Number(finance.total_earned)),
      },
    };
  }

  /**
   * Get earnings graph data as a separate endpoint payload
   */
  async getMerchantEarningsGraph(
    merchantId: string,
    query: MerchantEarningsGraphQueryDto,
  ): Promise<MerchantEarningsGraph> {
    const responseRange = query.range || '7d';
    const effectiveRange = this.normalizeGraphRange(responseRange);

    const now = new Date();
    let start: Date;
    let end: Date;
    let month: string | null = null;
    let monthLabel: string | null = null;
    let bucketExpression = "DATE_TRUNC('day', txn.created_at)";
    let bucketMode: 'hour' | 'day' | 'month' = 'day';

    if (effectiveRange === '24h') {
      const currentHourStart = this.getUtcStartOfHour(now);
      start = this.addUtcHours(currentHourStart, -23);
      end = this.addUtcHours(currentHourStart, 1);
      bucketExpression = "DATE_TRUNC('hour', txn.created_at)";
      bucketMode = 'hour';
    } else if (effectiveRange === '7d') {
      const todayStart = this.getUtcStartOfDay(now);
      start = this.addUtcDays(todayStart, -6);
      end = this.addUtcDays(todayStart, 1);
    } else if (effectiveRange === '30d') {
      const todayStart = this.getUtcStartOfDay(now);
      start = this.addUtcDays(todayStart, -29);
      end = this.addUtcDays(todayStart, 1);
    } else if (effectiveRange === '12m') {
      const currentMonthStart = this.getUtcStartOfMonth(now);
      start = this.addUtcMonths(currentMonthStart, -11);
      end = this.addUtcMonths(currentMonthStart, 1);
      bucketExpression = "DATE_TRUNC('month', txn.created_at)";
      bucketMode = 'month';
    } else {
      const monthDate = this.parseMonthToUtcDate(query.month);
      start = new Date(
        Date.UTC(monthDate.getUTCFullYear(), monthDate.getUTCMonth(), 1),
      );
      end = new Date(
        Date.UTC(monthDate.getUTCFullYear(), monthDate.getUTCMonth() + 1, 1),
      );
      month = `${monthDate.getUTCFullYear()}-${String(
        monthDate.getUTCMonth() + 1,
      ).padStart(2, '0')}`;
      monthLabel = this.formatMonthName(start);
      bucketMode = 'day';
    }

    const rows = await this.transactionRepository
      .createQueryBuilder('txn')
      .select(bucketExpression, 'bucket')
      .addSelect(
        `COALESCE(SUM(CASE
          WHEN txn.transaction_type = :creditType THEN txn.amount
          WHEN txn.transaction_type = :debitType THEN -txn.amount
          ELSE 0
        END), 0)`,
        'earnings',
      )
      .where('txn.merchant_id = :merchantId', { merchantId })
      .andWhere('txn.reference_type IN (:...referenceTypes)', {
        referenceTypes: this.earningsReferenceTypes,
      })
      .andWhere('txn.created_at >= :start', { start })
      .andWhere('txn.created_at < :end', { end })
      .groupBy(bucketExpression)
      .orderBy(bucketExpression, 'ASC')
      .setParameters({
        creditType: FinanceTransactionType.CREDIT,
        debitType: FinanceTransactionType.DEBIT,
      })
      .getRawMany<{ bucket: string; earnings: string }>();

    const earningsByBucket = new Map<string, number>();

    rows.forEach((row) => {
      const bucketDate = new Date(row.bucket);
      const bucketKey =
        bucketMode === 'hour'
          ? this.getUtcHourKey(bucketDate)
          : bucketMode === 'month'
            ? this.getUtcMonthKey(bucketDate)
            : this.getUtcDateKey(bucketDate);

      earningsByBucket.set(
        bucketKey,
        this.roundMoney(Number(row.earnings) || 0),
      );
    });

    const points: MerchantEarningsGraphPoint[] = [];

    if (bucketMode === 'hour') {
      for (
        let cursor = new Date(start);
        cursor < end;
        cursor = this.addUtcHours(cursor, 1)
      ) {
        const date = this.getUtcHourKey(cursor);
        const earnings = this.roundMoney(earningsByBucket.get(date) || 0);

        points.push({
          label: this.formatHourLabel(cursor),
          date,
          earnings,
        });
      }
    } else if (bucketMode === 'month') {
      for (
        let cursor = new Date(start);
        cursor < end;
        cursor = this.addUtcMonths(cursor, 1)
      ) {
        const date = this.getUtcMonthKey(cursor);
        const earnings = this.roundMoney(earningsByBucket.get(date) || 0);

        points.push({
          label: this.formatMonthShort(cursor),
          date,
          earnings,
        });
      }
    } else {
      for (
        let cursor = new Date(start);
        cursor < end;
        cursor = this.addUtcDays(cursor, 1)
      ) {
        const date = this.getUtcDateKey(cursor);
        const earnings = this.roundMoney(earningsByBucket.get(date) || 0);

        points.push({
          label:
            effectiveRange === '7d'
              ? this.formatWeekdayShort(cursor)
              : `${cursor.getUTCDate()}`,
          date,
          earnings,
        });
      }
    }

    const totalEarnings = this.roundMoney(
      points.reduce((sum, point) => sum + point.earnings, 0),
    );
    const periodDays = Math.max(
      1,
      (end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24),
    );
    const dailyAverage = this.roundMoney(totalEarnings / periodDays);
    const peakPoint =
      points.length > 0
        ? points.reduce((peak, point) =>
            point.earnings > peak.earnings ? point : peak,
          )
        : null;

    return {
      range: responseRange,
      month,
      month_label: monthLabel,
      points,
      summary: {
        peak_day: peakPoint?.label || null,
        peak_day_earnings: peakPoint?.earnings || 0,
        total_earnings: totalEarnings,
        daily_average: dailyAverage,
      },
    };
  }

  private normalizeGraphRange(
    range: MerchantEarningsGraphQueryDto['range'],
  ): '24h' | '7d' | '30d' | '12m' | 'monthly' {
    if (range === 'weekly') {
      return '7d';
    }

    if (
      range === '24h' ||
      range === '7d' ||
      range === '30d' ||
      range === '12m' ||
      range === 'monthly'
    ) {
      return range;
    }

    return '7d';
  }

  private getUtcStartOfHour(date: Date): Date {
    return new Date(
      Date.UTC(
        date.getUTCFullYear(),
        date.getUTCMonth(),
        date.getUTCDate(),
        date.getUTCHours(),
      ),
    );
  }

  private getUtcStartOfDay(date: Date): Date {
    return new Date(
      Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()),
    );
  }

  private addUtcDays(date: Date, days: number): Date {
    return new Date(
      Date.UTC(
        date.getUTCFullYear(),
        date.getUTCMonth(),
        date.getUTCDate() + days,
      ),
    );
  }

  private addUtcHours(date: Date, hours: number): Date {
    return new Date(
      Date.UTC(
        date.getUTCFullYear(),
        date.getUTCMonth(),
        date.getUTCDate(),
        date.getUTCHours() + hours,
      ),
    );
  }

  private getUtcStartOfMonth(date: Date): Date {
    return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), 1));
  }

  private addUtcMonths(date: Date, months: number): Date {
    return new Date(
      Date.UTC(date.getUTCFullYear(), date.getUTCMonth() + months, 1),
    );
  }

  private getUtcDateKey(date: Date): string {
    return date.toISOString().slice(0, 10);
  }

  private getUtcHourKey(date: Date): string {
    return `${date.toISOString().slice(0, 13)}:00:00Z`;
  }

  private getUtcMonthKey(date: Date): string {
    return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}`;
  }

  private formatMonthName(date: Date): string {
    return new Intl.DateTimeFormat('en-US', {
      month: 'long',
      timeZone: 'UTC',
    }).format(date);
  }

  private formatWeekdayShort(date: Date): string {
    return new Intl.DateTimeFormat('en-US', {
      weekday: 'short',
      timeZone: 'UTC',
    }).format(date);
  }

  private formatMonthShort(date: Date): string {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      timeZone: 'UTC',
    }).format(date);
  }

  private formatHourLabel(date: Date): string {
    const hour = String(date.getUTCHours()).padStart(2, '0');
    return `${hour}:00`;
  }

  private formatDayMonthYear(date: Date): string {
    return new Intl.DateTimeFormat('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      timeZone: 'UTC',
    }).format(date);
  }

  private parseMonthToUtcDate(month?: string): Date {
    if (!month) {
      return new Date();
    }

    const [yearString, monthString] = month.split('-');
    const year = Number(yearString);
    const monthIndex = Number(monthString);

    if (!year || !monthIndex || monthIndex < 1 || monthIndex > 12) {
      throw new BadRequestException('Invalid month format. Use YYYY-MM');
    }

    return new Date(Date.UTC(year, monthIndex - 1, 1));
  }

  private roundMoney(value: number): number {
    return Math.round((value + Number.EPSILON) * 100) / 100;
  }

  // ===== TRANSACTION RECORDING =====

  /**
   * Record a parcel delivery transaction
   * Called when parcel reaches terminal status (DELIVERED, PARTIAL_DELIVERY, etc.)
   */
  async recordParcelTransaction(
    merchantId: string,
    dto: RecordParcelTransactionDto,
    createdBy?: string,
  ): Promise<MerchantFinanceTransaction> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Get or create finance record
      let finance = await queryRunner.manager.findOne(MerchantFinance, {
        where: { merchant_id: merchantId },
      });

      if (!finance) {
        finance = queryRunner.manager.create(MerchantFinance, {
          merchant_id: merchantId,
        });
        await queryRunner.manager.save(MerchantFinance, finance);
      }

      const balanceBefore = Number(finance.pending_balance);
      const netPayable = dto.net_payable;

      // Determine reference type based on parcel status
      let referenceType: FinanceReferenceType;
      let transactionType: FinanceTransactionType;

      const deliveredStatuses = ['DELIVERED', 'PARTIAL_DELIVERY', 'EXCHANGE'];
      const returnedStatuses = [
        'RETURNED',
        'PAID_RETURN',
        'RETURNED_TO_HUB',
        'RETURN_TO_MERCHANT',
      ];

      if (deliveredStatuses.includes(dto.parcel_status)) {
        referenceType =
          dto.parcel_status === 'PARTIAL_DELIVERY'
            ? FinanceReferenceType.PARCEL_PARTIAL_DELIVERY
            : dto.parcel_status === 'EXCHANGE'
              ? FinanceReferenceType.PARCEL_EXCHANGE
              : FinanceReferenceType.PARCEL_DELIVERED;
        transactionType =
          netPayable >= 0
            ? FinanceTransactionType.CREDIT
            : FinanceTransactionType.DEBIT;

        // Update delivered count
        finance.total_parcels_delivered += 1;
      } else if (returnedStatuses.includes(dto.parcel_status)) {
        referenceType =
          dto.parcel_status === 'PAID_RETURN'
            ? FinanceReferenceType.PARCEL_PAID_RETURN
            : FinanceReferenceType.RETURN_CHARGE;
        transactionType =
          netPayable >= 0
            ? FinanceTransactionType.CREDIT
            : FinanceTransactionType.DEBIT;

        // Update returned count
        finance.total_parcels_returned += 1;
      } else {
        throw new BadRequestException(
          `Invalid parcel status: ${dto.parcel_status}`,
        );
      }

      // Update pending balance (money waiting to be invoiced)
      const newPendingBalance = balanceBefore + netPayable;
      finance.pending_balance = newPendingBalance;

      // Update lifetime stats
      finance.total_cod_collected =
        Number(finance.total_cod_collected) + dto.cod_collected;
      finance.total_delivery_charges =
        Number(finance.total_delivery_charges) + dto.delivery_charge;
      finance.total_return_charges =
        Number(finance.total_return_charges) + dto.return_charge;
      finance.last_transaction_at = new Date();

      await queryRunner.manager.save(MerchantFinance, finance);

      // Create transaction record
      const transaction = queryRunner.manager.create(
        MerchantFinanceTransaction,
        {
          merchant_id: merchantId,
          transaction_type: transactionType,
          amount: Math.abs(netPayable),
          balance_before: balanceBefore,
          balance_after: newPendingBalance,
          reference_type: referenceType,
          reference_id: dto.parcel_id,
          reference_code: dto.tracking_number,
          description:
            dto.description ||
            `Parcel ${dto.tracking_number} - ${dto.parcel_status}`,
          cod_amount: dto.cod_collected,
          delivery_charge: dto.delivery_charge,
          return_charge: dto.return_charge,
          created_by: createdBy,
          metadata: {
            parcel_status: dto.parcel_status,
          },
        },
      );

      await queryRunner.manager.save(MerchantFinanceTransaction, transaction);

      await queryRunner.commitTransaction();

      this.logger.log(
        `Recorded parcel transaction for merchant ${merchantId}: ${dto.tracking_number} = ${netPayable}`,
      );

      return transaction;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      this.logger.error(
        `Failed to record parcel transaction: ${error.message}`,
      );
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  /**
   * Move balance from pending to invoiced when invoice is created
   */
  async moveToInvoiced(
    merchantId: string,
    amount: number,
    invoiceId: string,
    invoiceNo: string,
    createdBy?: string,
  ): Promise<void> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const finance = await queryRunner.manager.findOne(MerchantFinance, {
        where: { merchant_id: merchantId },
      });

      if (!finance) {
        throw new NotFoundException('Merchant finance record not found');
      }

      // Decrease pending, increase invoiced
      finance.pending_balance = Number(finance.pending_balance) - amount;
      finance.invoiced_balance = Number(finance.invoiced_balance) + amount;
      finance.last_transaction_at = new Date();

      await queryRunner.manager.save(MerchantFinance, finance);

      // No transaction record needed for internal balance movement
      // The invoice itself serves as the record

      await queryRunner.commitTransaction();

      this.logger.log(
        `Moved ${amount} from pending to invoiced for merchant ${merchantId}, invoice ${invoiceNo}`,
      );
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  /**
   * Move balance from invoiced to processing when admin starts processing
   */
  async moveToProcessing(
    merchantId: string,
    amount: number,
    invoiceId: string,
  ): Promise<void> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const finance = await queryRunner.manager.findOne(MerchantFinance, {
        where: { merchant_id: merchantId },
      });

      if (!finance) {
        throw new NotFoundException('Merchant finance record not found');
      }

      // Move from invoiced to processing
      finance.invoiced_balance = Number(finance.invoiced_balance) - amount;
      finance.processing_balance = Number(finance.processing_balance) + amount;

      await queryRunner.manager.save(MerchantFinance, finance);
      await queryRunner.commitTransaction();

      this.logger.log(
        `Moved ${amount} from invoiced to processing for merchant ${merchantId}`,
      );
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  /**
   * Move balance back from processing to invoiced (if payment cancelled)
   */
  async moveBackToInvoiced(
    merchantId: string,
    amount: number,
    invoiceId: string,
  ): Promise<void> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const finance = await queryRunner.manager.findOne(MerchantFinance, {
        where: { merchant_id: merchantId },
      });

      if (!finance) {
        throw new NotFoundException('Merchant finance record not found');
      }

      // Move back from processing to invoiced
      finance.processing_balance = Number(finance.processing_balance) - amount;
      finance.invoiced_balance = Number(finance.invoiced_balance) + amount;

      await queryRunner.manager.save(MerchantFinance, finance);
      await queryRunner.commitTransaction();

      this.logger.log(
        `Moved ${amount} back from processing to invoiced for merchant ${merchantId}`,
      );
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  /**
   * Record invoice payment (withdrawal from merchant balance)
   */
  async recordInvoicePayment(
    merchantId: string,
    amount: number,
    invoiceId: string,
    invoiceNo: string,
    paymentReference: string | null,
    paidBy: string,
  ): Promise<MerchantFinanceTransaction> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const finance = await queryRunner.manager.findOne(MerchantFinance, {
        where: { merchant_id: merchantId },
      });

      if (!finance) {
        throw new NotFoundException('Merchant finance record not found');
      }

      // Get current balance before withdrawal
      // The amount should be in either invoiced or processing balance
      const processingAmount = Number(finance.processing_balance);
      const invoicedAmount = Number(finance.invoiced_balance);

      // Deduct from processing first, then invoiced
      const deductFromProcessing = Math.min(amount, processingAmount);
      const deductFromInvoiced = amount - deductFromProcessing;

      finance.processing_balance = processingAmount - deductFromProcessing;
      finance.invoiced_balance = invoicedAmount - deductFromInvoiced;

      // Update lifetime stats
      finance.total_withdrawn = Number(finance.total_withdrawn) + amount;
      finance.total_earned = Number(finance.total_earned) + amount;
      finance.last_withdrawal_at = new Date();
      finance.last_transaction_at = new Date();

      await queryRunner.manager.save(MerchantFinance, finance);

      // Create transaction record for the withdrawal
      const transaction = queryRunner.manager.create(
        MerchantFinanceTransaction,
        {
          merchant_id: merchantId,
          transaction_type: FinanceTransactionType.DEBIT,
          amount: amount,
          balance_before: processingAmount + invoicedAmount,
          balance_after:
            Number(finance.processing_balance) +
            Number(finance.invoiced_balance),
          reference_type: FinanceReferenceType.INVOICE_PAID,
          reference_id: invoiceId,
          reference_code: invoiceNo,
          description: `Invoice payment: ${invoiceNo}`,
          notes: paymentReference,
          created_by: paidBy,
          metadata: {
            payment_reference: paymentReference,
          },
        },
      );

      await queryRunner.manager.save(MerchantFinanceTransaction, transaction);

      await queryRunner.commitTransaction();

      this.logger.log(
        `Recorded invoice payment for merchant ${merchantId}: ${invoiceNo} = ${amount}`,
      );

      return transaction;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      this.logger.error(`Failed to record invoice payment: ${error.message}`);
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  // ===== ADMIN ADJUSTMENTS =====

  /**
   * Admin: Adjust merchant balance (credit or debit)
   */
  async adjustBalance(
    merchantId: string,
    dto: AdjustBalanceDto,
    adminUserId: string,
  ): Promise<MerchantFinanceTransaction> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const finance = await this.getOrCreateFinance(merchantId);
      const balanceBefore = Number(finance.current_balance);

      let newBalance: number;
      let referenceType: FinanceReferenceType;

      if (dto.type === FinanceTransactionType.CREDIT) {
        newBalance = balanceBefore + dto.amount;
        referenceType = FinanceReferenceType.ADJUSTMENT_CREDIT;
      } else {
        newBalance = balanceBefore - dto.amount;
        referenceType = FinanceReferenceType.ADJUSTMENT_DEBIT;
      }

      // Update finance record
      await queryRunner.manager.update(
        MerchantFinance,
        { merchant_id: merchantId },
        {
          current_balance: newBalance,
          last_transaction_at: new Date(),
        },
      );

      // Create transaction record
      const transaction = queryRunner.manager.create(
        MerchantFinanceTransaction,
        {
          merchant_id: merchantId,
          transaction_type: dto.type,
          amount: dto.amount,
          balance_before: balanceBefore,
          balance_after: newBalance,
          reference_type: referenceType,
          description: dto.reason,
          notes: dto.notes,
          created_by: adminUserId,
        },
      );

      await queryRunner.manager.save(MerchantFinanceTransaction, transaction);

      await queryRunner.commitTransaction();

      this.logger.log(
        `Admin ${adminUserId} adjusted balance for merchant ${merchantId}: ${dto.type} ${dto.amount}`,
      );

      return transaction;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  /**
   * Admin: Hold merchant balance
   */
  async holdBalance(
    merchantId: string,
    dto: HoldBalanceDto,
    adminUserId: string,
  ): Promise<MerchantFinance> {
    const finance = await this.getOrCreateFinance(merchantId);

    const availableToHold =
      Number(finance.current_balance) - Number(finance.hold_amount);

    if (dto.amount > availableToHold) {
      throw new BadRequestException(
        `Insufficient balance to hold. Available: ${availableToHold}`,
      );
    }

    finance.hold_amount = Number(finance.hold_amount) + dto.amount;
    await this.financeRepository.save(finance);

    this.logger.log(
      `Admin ${adminUserId} held ${dto.amount} for merchant ${merchantId}. Reason: ${dto.reason}`,
    );

    return finance;
  }

  /**
   * Admin: Release held balance
   */
  async releaseHold(
    merchantId: string,
    dto: ReleaseHoldDto,
    adminUserId: string,
  ): Promise<MerchantFinance> {
    const finance = await this.getOrCreateFinance(merchantId);

    if (dto.amount > Number(finance.hold_amount)) {
      throw new BadRequestException(
        `Cannot release more than held amount. Held: ${finance.hold_amount}`,
      );
    }

    finance.hold_amount = Number(finance.hold_amount) - dto.amount;
    await this.financeRepository.save(finance);

    this.logger.log(
      `Admin ${adminUserId} released ${dto.amount} hold for merchant ${merchantId}`,
    );

    return finance;
  }

  // ===== TRANSACTION HISTORY =====

  /**
   * Get merchant transaction history
   */
  async getTransactionHistory(
    merchantId: string,
    query: GetTransactionsQueryDto,
  ): Promise<TransactionListResponse> {
    const {
      page = 1,
      limit = 20,
      transaction_type,
      reference_type,
      from_date,
      to_date,
      sort_by = 'created_at',
      sort_order = 'DESC',
    } = query;

    const queryBuilder = this.transactionRepository
      .createQueryBuilder('txn')
      .where('txn.merchant_id = :merchantId', { merchantId });

    // Apply filters
    if (transaction_type) {
      queryBuilder.andWhere('txn.transaction_type = :transaction_type', {
        transaction_type,
      });
    }

    if (reference_type) {
      queryBuilder.andWhere('txn.reference_type = :reference_type', {
        reference_type,
      });
    }

    if (from_date) {
      queryBuilder.andWhere('txn.created_at >= :from_date', { from_date });
    }

    if (to_date) {
      queryBuilder.andWhere('txn.created_at <= :to_date', { to_date });
    }

    // Get total count
    const total = await queryBuilder.getCount();

    // Apply sorting and pagination
    queryBuilder
      .orderBy(`txn.${sort_by}`, sort_order)
      .skip((page - 1) * limit)
      .take(limit);

    const transactions = await queryBuilder.getMany();

    // Calculate summary
    const summaryQueryBuilder = this.transactionRepository
      .createQueryBuilder('txn')
      .select('txn.transaction_type', 'type')
      .addSelect('SUM(txn.amount)', 'total')
      .where('txn.merchant_id = :merchantId', { merchantId })
      .groupBy('txn.transaction_type');

    const summaryResults = await summaryQueryBuilder.getRawMany();

    let totalCredits = 0;
    let totalDebits = 0;

    summaryResults.forEach((result) => {
      if (result.type === FinanceTransactionType.CREDIT) {
        totalCredits = Number(result.total);
      } else {
        totalDebits = Number(result.total);
      }
    });

    return {
      transactions: transactions.map((txn) => ({
        id: txn.id,
        transaction_type: txn.transaction_type,
        amount: Number(txn.amount),
        balance_before: Number(txn.balance_before),
        balance_after: Number(txn.balance_after),
        reference_type: txn.reference_type,
        reference_id: txn.reference_id,
        reference_code: txn.reference_code,
        description: txn.description,
        cod_amount: txn.cod_amount ? Number(txn.cod_amount) : null,
        delivery_charge: txn.delivery_charge
          ? Number(txn.delivery_charge)
          : null,
        return_charge: txn.return_charge ? Number(txn.return_charge) : null,
        created_at: txn.created_at,
        created_by: txn.created_by,
      })),
      pagination: {
        total,
        page,
        limit,
        total_pages: Math.ceil(total / limit),
      },
      summary: {
        total_credits: totalCredits,
        total_debits: totalDebits,
        net_change: totalCredits - totalDebits,
      },
    };
  }

  // ===== ADMIN VIEWS =====

  /**
   * Admin: Get all merchants finance summary
   */
  async getAllMerchantsFinance(
    query: GetAllMerchantsFinanceQueryDto,
  ): Promise<AdminFinanceSummary> {
    const {
      page = 1,
      limit = 20,
      search,
      has_balance,
      has_pending,
      sort_by = 'current_balance',
      sort_order = 'DESC',
    } = query;

    const queryBuilder = this.financeRepository
      .createQueryBuilder('finance')
      .leftJoin(User, 'user', 'user.id = finance.merchant_id')
      .leftJoin(Merchant, 'merchant', 'merchant.user_id = finance.merchant_id')
      .select([
        'finance.merchant_id as merchant_id',
        'user.id as user_id',
        'user.full_name as name',
        'user.phone as phone',
        'finance.current_balance as current_balance',
        'finance.pending_balance as pending_balance',
        'finance.invoiced_balance as invoiced_balance',
        'finance.total_earned as total_earned',
        'finance.total_parcels_delivered as total_parcels_delivered',
        'finance.last_transaction_at as last_transaction_at',
      ]);

    // Apply filters
    if (search) {
      queryBuilder.andWhere(
        '(user.full_name ILIKE :search OR user.phone ILIKE :search)',
        { search: `%${search}%` },
      );
    }

    if (has_balance) {
      queryBuilder.andWhere('finance.current_balance > 0');
    }

    if (has_pending) {
      queryBuilder.andWhere(
        '(finance.pending_balance > 0 OR finance.invoiced_balance > 0)',
      );
    }

    // Get total count
    const totalCount = await queryBuilder.getCount();

    // Get totals
    const totalsQuery = await this.financeRepository
      .createQueryBuilder('finance')
      .select('COUNT(*)', 'total_merchants')
      .addSelect('SUM(finance.current_balance)', 'total_current_balance')
      .addSelect('SUM(finance.pending_balance)', 'total_pending_balance')
      .addSelect('SUM(finance.invoiced_balance)', 'total_invoiced_balance')
      .addSelect('SUM(finance.processing_balance)', 'total_processing_balance')
      .addSelect('SUM(finance.hold_amount)', 'total_hold_amount')
      .getRawOne();

    // Apply sorting and pagination
    queryBuilder
      .orderBy(`finance.${sort_by}`, sort_order)
      .offset((page - 1) * limit)
      .limit(limit);

    const merchants = await queryBuilder.getRawMany();

    return {
      totals: {
        total_merchants: Number(totalsQuery.total_merchants),
        total_current_balance: Number(totalsQuery.total_current_balance) || 0,
        total_pending_balance: Number(totalsQuery.total_pending_balance) || 0,
        total_invoiced_balance: Number(totalsQuery.total_invoiced_balance) || 0,
        total_processing_balance:
          Number(totalsQuery.total_processing_balance) || 0,
        total_hold_amount: Number(totalsQuery.total_hold_amount) || 0,
      },
      merchants: merchants.map((m) => ({
        merchant_id: m.merchant_id,
        user_id: m.user_id,
        name: m.name,
        phone: m.phone,
        current_balance: Number(m.current_balance) || 0,
        pending_balance: Number(m.pending_balance) || 0,
        invoiced_balance: Number(m.invoiced_balance) || 0,
        total_earned: Number(m.total_earned) || 0,
        total_parcels_delivered: m.total_parcels_delivered || 0,
        last_transaction_at: m.last_transaction_at,
      })),
      pagination: {
        total: totalCount,
        page,
        limit,
        total_pages: Math.ceil(totalCount / limit),
      },
    };
  }

  /**
   * Sync merchant finance from existing parcels
   * Used for initial migration or data reconciliation
   */
  async syncMerchantFinance(merchantId: string): Promise<MerchantFinance> {
    const terminalStatuses = [
      ParcelStatus.DELIVERED,
      ParcelStatus.PARTIAL_DELIVERY,
      ParcelStatus.EXCHANGE,
      ParcelStatus.PAID_RETURN,
      ParcelStatus.RETURNED,
      ParcelStatus.RETURNED_TO_HUB,
      ParcelStatus.RETURN_TO_MERCHANT,
    ];

    const deliveredStatuses = [
      ParcelStatus.DELIVERED,
      ParcelStatus.PARTIAL_DELIVERY,
      ParcelStatus.EXCHANGE,
    ];

    const returnedStatuses = [
      ParcelStatus.RETURNED,
      ParcelStatus.PAID_RETURN,
      ParcelStatus.RETURNED_TO_HUB,
      ParcelStatus.RETURN_TO_MERCHANT,
    ];

    // Get all terminal parcels for this merchant
    const parcels = await this.parcelRepository.find({
      where: {
        merchant_id: merchantId,
        status: In(terminalStatuses),
      },
    });

    let totalCodCollected = 0;
    let totalDeliveryCharges = 0;
    let totalReturnCharges = 0;
    let pendingBalance = 0;
    let invoicedBalance = 0;
    let deliveredCount = 0;
    let returnedCount = 0;
    let totalWithdrawn = 0;

    for (const parcel of parcels) {
      const codCollected = Number(parcel.cod_collected_amount) || 0;
      const deliveryCharge = parcel.delivery_charge_applicable
        ? Number(parcel.total_charge) || 0
        : 0;
      const returnCharge = parcel.return_charge_applicable
        ? Number(parcel.return_charge) || 0
        : 0;
      const netPayable = codCollected - deliveryCharge - returnCharge;

      totalCodCollected += codCollected;
      totalDeliveryCharges += deliveryCharge;
      totalReturnCharges += returnCharge;

      // Categorize by invoice status
      if (parcel.paid_to_merchant) {
        totalWithdrawn += netPayable;
      } else if (parcel.invoice_id) {
        invoicedBalance += netPayable;
      } else {
        pendingBalance += netPayable;
      }

      // Count by status
      if (deliveredStatuses.includes(parcel.status)) {
        deliveredCount++;
      } else if (returnedStatuses.includes(parcel.status)) {
        returnedCount++;
      }
    }

    // Update or create finance record
    let finance = await this.financeRepository.findOne({
      where: { merchant_id: merchantId },
    });

    if (!finance) {
      finance = this.financeRepository.create({
        merchant_id: merchantId,
      });
    }

    finance.pending_balance = pendingBalance;
    finance.invoiced_balance = invoicedBalance;
    finance.total_cod_collected = totalCodCollected;
    finance.total_delivery_charges = totalDeliveryCharges;
    finance.total_return_charges = totalReturnCharges;
    finance.total_parcels_delivered = deliveredCount;
    finance.total_parcels_returned = returnedCount;
    finance.total_withdrawn = totalWithdrawn;
    finance.total_earned = totalWithdrawn;

    await this.financeRepository.save(finance);

    this.logger.log(`Synced finance for merchant ${merchantId}`);

    return finance;
  }

  /**
   * Sync all merchants' finance records
   */
  async syncAllMerchantsFinance(): Promise<{ synced: number; errors: number }> {
    const merchants = await this.merchantRepository.find();

    let synced = 0;
    let errors = 0;

    for (const merchant of merchants) {
      try {
        await this.syncMerchantFinance(merchant.user_id);
        synced++;
      } catch (error) {
        this.logger.error(
          `Failed to sync finance for merchant ${merchant.user_id}: ${error.message}`,
        );
        errors++;
      }
    }

    return { synced, errors };
  }

  /**
   * Generic method to create a finance transaction
   * Can be used for Advance Payments, Adjustments, etc.
   */
  async createTransaction(
    dto: CreateTransactionDto,
  ): Promise<MerchantFinanceTransaction> {
    // Hard block for advance payments if merchant has disabled the feature
    if (dto.transaction_type === FinanceTransactionType.ADVANCE_PAYMENT) {
      const merchant = await this.merchantRepository.findOne({
        where: { user_id: dto.merchant_id },
      });

      if (!merchant) {
        throw new NotFoundException('Merchant not found');
      }

      if (merchant.is_advance_payment_disabled) {
        throw new ForbiddenException(
          'Advance payment feature is disabled for this merchant',
        );
      }
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // 1. Get or create finance record
      let finance = await queryRunner.manager.findOne(MerchantFinance, {
        where: { merchant_id: dto.merchant_id },
      });

      if (!finance) {
        finance = queryRunner.manager.create(MerchantFinance, {
          merchant_id: dto.merchant_id,
          current_balance: 0,
          pending_balance: 0,
          invoiced_balance: 0,
          processing_balance: 0,
        });
        await queryRunner.manager.save(MerchantFinance, finance);
      }

      const balanceBefore = Number(finance.current_balance);
      let newBalance = balanceBefore;

      // 2. Update Balance based on Transaction Type
      // Advance Payment is a WITHDRAWAL/DEBIT operation (reduces balance)
      if (dto.transaction_type === FinanceTransactionType.ADVANCE_PAYMENT) {
        // Amount should be passed as negative, or we subtract absolute value
        // Let's assume the caller passes a negative amount for deductions
        newBalance = balanceBefore + dto.amount;

        // Update stats
        finance.total_withdrawn =
          Number(finance.total_withdrawn) + Math.abs(dto.amount);
        finance.last_withdrawal_at = new Date();
      } else if (dto.transaction_type === FinanceTransactionType.DEBIT) {
        newBalance = balanceBefore - Math.abs(dto.amount);
      } else if (dto.transaction_type === FinanceTransactionType.CREDIT) {
        newBalance = balanceBefore + Math.abs(dto.amount);
      }

      // Update Finance Record
      finance.current_balance = newBalance;
      finance.last_transaction_at = new Date();
      await queryRunner.manager.save(MerchantFinance, finance);

      // 3. Create Transaction Record
      const transaction = queryRunner.manager.create(
        MerchantFinanceTransaction,
        {
          merchant_id: dto.merchant_id,
          transaction_type: dto.transaction_type, // Now supports ADVANCE_PAYMENT
          amount: dto.amount,
          balance_before: balanceBefore,
          balance_after: newBalance,
          reference_type: dto.reference_type,
          reference_id: dto.reference_id,
          reference_code: dto.reference_code || null,
          description: dto.description,
          created_by: dto.created_by,
        },
      );

      await queryRunner.manager.save(MerchantFinanceTransaction, transaction);
      await queryRunner.commitTransaction();

      this.logger.log(
        `Created transaction for merchant ${dto.merchant_id}: ${dto.transaction_type} ${dto.amount}. New Balance: ${newBalance}`,
      );

      return transaction;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      this.logger.error(`Failed to create transaction: ${error.message}`);
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
