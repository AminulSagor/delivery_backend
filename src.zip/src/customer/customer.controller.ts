import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Param,
  Body,
  Query,
  BadRequestException,
  UseGuards,
} from '@nestjs/common';
import { CustomerService } from './customer.service';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { CheckCustomerPhoneDto } from './dto/check-customer-phone.dto';
import { PaginationDto } from '../common/dto/pagination.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { UserRole } from '../common/enums/user-role.enum';

@Controller('customers')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(UserRole.MERCHANT)
export class CustomerController {
  constructor(private readonly customerService: CustomerService) {}

  // 🔹 Frontend: first step → give only phone, check if exists
  @Post('check')
  async checkCustomer(
    @Body() dto: CheckCustomerPhoneDto,
    @CurrentUser() user: any,
  ) {
    const result = await this.customerService.checkByPhone(dto.phone_number);
    return {
      ...result,
      phone_number: dto.phone_number,
    };
  }

  // 🔹 Create full customer (called if check says exists === false)
  @Post()
  async create(@CurrentUser() user: any, @Body() dto: CreateCustomerDto) {
    const customer = await this.customerService.create(dto);
    return {
      customer,
      message: 'Customer created successfully',
    };
  }

  @Get()
  async findAll(
    @CurrentUser('merchantId') merchantId: string,
    @Query() query: PaginationDto,
  ) {
    if (!merchantId) {
      throw new BadRequestException('Merchant ID not found in user context');
    }

    const result = await this.customerService.findAll(merchantId, query);
    return {
      success: true,
      data: result.items,
      pagination: result.pagination,
      message: 'Customers retrieved successfully',
    };
  }

  @Get('get/:phone')
  async getByPhone(@Param('phone') phone: string, @CurrentUser() user: any) {
    if (!user.merchantId) {
      return {
        success: false,
        message: 'Merchant ID not found in user context',
      };
    }

    return await this.customerService.getCustomerByPhone(
      phone,
      user.merchantId,
    );
  }

  // Get customer by phone number instead of id
  @Get(':phone')
  async findOne(@Param('phone') phone: string, @CurrentUser() user: any) {
    return await this.customerService.findOneByPhone(phone);
  }

  // Update customer by phone number
  @Patch(':phone')
  async update(
    @Param('phone') phone: string,
    @CurrentUser() user: any,
    @Body() dto: UpdateCustomerDto,
  ) {
    const customer = await this.customerService.update(phone, dto);
    return {
      customer,
      message: 'Customer updated successfully',
    };
  }

  // Delete customer by phone number
  @Delete(':phone')
  async remove(@Param('phone') phone: string, @CurrentUser() user: any) {
    await this.customerService.remove(phone);
    return {
      deleted: true,
      message: 'Customer deleted successfully',
    };
  }
}
