import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { dataSourceOptions } from './data-source';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AdminModule } from './admin/admin.module';
import { MerchantModule } from './merchant/merchant.module';
import { UsersModule } from './users/users.module';
import { HubsModule } from './hubs/hubs.module';
import { RidersModule } from './riders/riders.module';
import { AuthModule } from './auth/auth.module';
import { StoresModule } from './stores/stores.module';
import { CoverageAreasModule } from './coverage-areas/coverage-areas.module';
import { ParcelsModule } from './parcels/parcels.module';
import { PricingModule } from './pricing/pricing.module';
import { CustomerModule } from './customer/customer.module';
import { PickupRequestsModule } from './pickup-requests/pickup-requests.module';
import { DeliveryVerificationsModule } from './delivery-verifications/delivery-verifications.module';
import { ThirdPartyProvidersModule } from './third-party-providers/third-party-providers.module';
import { CarrybeeModule } from './carrybee/carrybee.module';
import { CarrybeeLocationsModule } from './carrybee-locations/carrybee-locations.module';
import { UploadModule } from './upload/upload.module';
import { MerchantFinanceModule } from './merchant-finance/merchant-finance.module';
import { BanksModule } from './banks/banks.module';
import { AdvancePaymentsModule } from './advance-payments/advance-payments.module';
import { StaffModule } from './staff/staff.module';
import { SalaryModule } from './salary/salary.module';
import { CarrybeeAssignmentWorker } from './workers/carrybee-assignment.worker';

// Synchronize is ALWAYS enabled - no manual migrations needed
// TypeORM will auto-create/update all tables based on entities

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    TypeOrmModule.forRoot({
      ...dataSourceOptions,
      autoLoadEntities: true,
      // Migrations disabled - synchronize handles everything automatically
      migrationsRun: false,
      retryAttempts: 5, // Reduced for Railway (faster fail if misconfigured)
      retryDelay: 2000, // 2s between retries
    }),
    AdminModule,
    MerchantModule,
    UsersModule,
    HubsModule,
    RidersModule,
    StaffModule,
    SalaryModule,
    AuthModule,
    StoresModule,
    CoverageAreasModule,
    ParcelsModule,
    PricingModule,
    CustomerModule,
    PickupRequestsModule,
    DeliveryVerificationsModule,
    ThirdPartyProvidersModule,
    CarrybeeModule,
    CarrybeeLocationsModule,
    UploadModule,
    MerchantFinanceModule,
    BanksModule,
    AdvancePaymentsModule,
  ],
  controllers: [AppController],
  providers: [AppService, CarrybeeAssignmentWorker],
})
export class AppModule {}
